frontend-nanodegree-arcade-game
===============================

Students should use this [rubric](https://review.udacity.com/#!/projects/2696458597/rubric) for self-checking their submission. Make sure the functions you write are **object-oriented** - either class functions (like Player and Enemy) or class prototype functions such as Enemy.prototype.checkCollisions, and that the keyword 'this' is used appropriately within your class and class prototype functions to refer to the object the function is called upon. Also be sure that the **readme.md** file is updated with your instructions on both how to 1. Run and 2. Play your arcade game.

For detailed instructions on how to get started, check out this [guide](https://docs.google.com/document/d/1v01aScPjSWCCWQLIpFqvg3-vXLH2e8_SZQKC8jNO0Dc/pub?embedded=true).

A).Steps to run the game-
   1)DOwnload the zip file.
   2)Unzip the file using WINRAR or any supportive format software
   3)After unziping the file, you will find 5 files,i.e.css,images,js,index,readme.
              a)The CSS folder includes the style.ss file
              b)The IMAGES folder includes the images which are used in the game.
              c)The JS folder includes the javascript code
   4)For playing the game click on index.html.
   5)For game instructions click on part B.

B).Steps to play the arcade game-
   1)Use the arrow keys to move.
   2)The objective is to reach the top of the water and collect gems to score.
   3)Each time you reach the top of the water, you win and again the game resets.
   4)Avoid the bugs, they kill you. You start with three lives.

