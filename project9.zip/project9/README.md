>>>>>>How to open the file
        1)download the zip folder
        2)unzip the folder with the use of softwares called winzip
        3)extract the files into one single folder
        4)click on index.html
        5)and open it into yout favroite browser

.......Every todo blanks were filled and the test was passed
 