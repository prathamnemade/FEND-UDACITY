#CAfe's in Mumbai
Project 8

>>>>>>> To use this app:
  1)Open index.html to see the cafe's in mumbai


>>>>>>>Framework**
- This app uses `knockout.js`. 

>>>>>>>APIs
  1)This app uses the **Google Maps API**.
  2)This app uses the **Media Wiki API**.

