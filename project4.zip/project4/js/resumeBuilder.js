var bio = {

    "name": "Prathamesh Nemade",
    "role": "Systems Engineer",
    "contacts": {


        "mobile": "9767545233",
        "email": "prathameshnemade95@gmail.com",
        "github": "@prathamnemade",
        "twitter": "@neymar",
        "location": "Mysore"
    },
    "welcomeMessage": "Seeking the position which offers opportunities for development in all sectors and where I can use my talent and skills for company’s growth.",
    "skills": ["PYTHON", "C++", "C", "JS", "jQuery", "JSON", "HTML", "Git", "Mobile ROMS"],
    "biopic": "images/pratham.jpg",



    display: function() {

        var formattedWelcomeMsg = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);
        $("#header").append(formattedWelcomeMsg);

        var formattedBioPic = HTMLbioPic.replace("%data%", bio.biopic);
        $("#header").append(formattedBioPic);

        var formattedRole = HTMLheaderRole.replace("%data%", bio.role);

        $("#header").prepend(formattedRole);

        var formattedName = HTMLheaderName.replace("%data%", bio.name);
        $("#header").prepend(formattedName);



        var info = [];
        info.push(HTMLemail.replace("%data%", bio.contacts.email));
        info.push(HTMLgithub.replace("%data%", bio.contacts.github));
        info.push(HTMLtwitter.replace("%data%", bio.contacts.twitter));
        info.push(HTMLlocation.replace("%data%", bio.contacts.location));

        //for (var i in info) {
        info.forEach(function(ids) {

            $("#topContacts").append(ids);
        });

        $("#footerContacts").append(HTMLemail.replace("%data%", bio.contacts.email));



        if (bio.skills.length > 0) {
            $("#header").append(HTMLskillsStart);

            //for (i in bio.skills) {
            bio.skills.forEach(function(skill) {

                $("#skills").append(HTMLskills.replace("%data%", skill));
            });
        }




    }

};
bio.display();


var education = {
    "schools": [{
        "name": "VJTI",
        "location": "Mumbai",
        "degree": "B.TECH in ELECTRICAL",
        "majors": ["ELECTRICAL"],
        "dates": "2013-2017",
        "url": "http://www.vjti.ac.in/"
    }],
    "onlineCourses": [{
            "title": "Front-End Developer",
            "school": "UDACITY",
            "dates": "June 15-Aug 30",
            "url": "https://classroom.udacity.com/me"
        },
        {
            "title": "Learn Bcakbone.js",
            "school": "UDACITY",
            "dates": "July 10-July 15",
            "url": "https://classroom.udacity.com/me"
        },
        {
            "title": "GitHub & Collaboration",
            "school": "UDACITY",
            "dates": "July 18-July 19",
            "url": "https://classroom.udacity.com/me"
        },
        {
            "title": "Version Control with Git",
            "school": "UDACITY",
            "dates": "July 18-July 19",
            "url": "https://classroom.udacity.com/me"
        }
    ],
    display: function() {
        //education.display = function() {

        if (education.schools.length > 0 || education.onlineCourses.length > 0) {
            education.schools.forEach(function(edu) {
                //for (var i in education.schools) {
                $("#education").append(HTMLschoolStart);

                var formattedSchoolName = HTMLschoolName.replace("%data%", edu.name);
                var formattedSchoolDegree = HTMLschoolDegree.replace("%data%", edu.degree);
                var formattedSchoolDates = HTMLschoolDates.replace("%data%", edu.dates);
                var formattedSchoolLocation = HTMLschoolLocation.replace("%data%", edu.location);
                var formattedSchoolMajor = HTMLschoolMajor.replace("%data%", edu.majors);

                $(".education-entry:last").append(formattedSchoolName);
                $(".education-entry:last").append(formattedSchoolDates);
                $(".education-entry:last").append(formattedSchoolLocation);
                $(".education-entry:last").append(formattedSchoolMajor);

            });


            if (education.onlineCourses.length > 0) {
                $("#education").append(HTMLonlineClasses);
                education.onlineCourses.forEach(function(cour) {
                    //for (i in education.onlineCourses) {
                    $("#education").append(HTMLschoolStart);
                    var formattedOnlineTitle = HTMLonlineTitle.replace("%data%", cour.title);
                    var formattedOnlineSchool = HTMLonlineSchool.replace("%data%", cour.school);
                    var formattedOnlineDates = HTMLonlineDates.replace("%data%", cour.dates);
                    var formattedOnlineURL = HTMLonlineURL.replace("%data%", cour.url);

                    $(".education-entry:last").append(formattedOnlineTitle + formattedOnlineSchool);
                    $(".education-entry:last").append(formattedOnlineDates);
                    $(".education-entry:last").append(formattedOnlineURL);
                });
            }

        }
    }

};
education.display();




var work = {
    "jobs": [{
            "employer": "Central Railway",
            "title": "Intern",
            "location": "Mumbai",
            "dates": "15/6/2015 - 30/6/2015",
            "description": "Was a trainee under a mentor. Learned about various section in making of Train such as Pantograph Section, Breaking Section, AWS ,etc. Basic idea of Transmission                    lines  and wiring in train was learned."
        },
        {

            "employer": "Raymond UCO Denim",
            "title": "Intern",
            "location": "Yavatmal",
            "dates": "01/12/2015 - 20/12/2015",
            "description": "UCO Denim Plant contains Solar power Plant, Thermal Plant and Furnace Oil Plant.Maintained current knowledge about the latest operating and maintenance practices               with   continuing education courses. Basics about textile plant was learned."
        },
        {
            "employer": "Infosys",
            "title": "Systems Engineer",
            "location": "Mysore",
            "dates": 'In Progress',
            "description":""
        }
    ],
    display: function() {

        //work.display = function() {
        if (work.jobs.length > 0) {
            //for (var job in work.jobs) {
            work.jobs.forEach(function(work) {
                $("#workExperience").append(HTMLworkStart);

                var formattedEmployer = HTMLworkEmployer.replace("%data%", work.employer);
                $(".work-entry:last").append(formattedEmployer);
                var formattedTitle = HTMLworkTitle.replace("%data%", work.title);
                $(".work-entry:last").append(formattedTitle);

                var formattedLocation = HTMLworkLocation.replace("%data%", work.location);
                $(".work-entry:last").append(formattedLocation);
                var formattedDates = HTMLworkDates.replace("%data%", work.dates);
                $(".work-entry:last").append(formattedDates);
                var formattedDescription = HTMLworkDescription.replace("%data%", work.description);
                $(".work-entry:last").append(formattedDescription);
            });
        }
    }
};
work.display();




var projects = {

    "projects": [{
            "title": "Electromagnetic Impulse Generator",
            "dates": "Dec 2016 - May 2017",
            "description": "Marx Generator and Simulations ",
            "images": ["https://pratham.com"]
        },
        {
            "title": "Kaun Banega Crorepati Game",
            "dates": "Jan 2009- April 2009",
            "description": "Designed a game in C++",
            "images": ["https://www.youtube.com/watch?v=gSwQQB_MlxM"]
        },
        {
            "title": "HydroPower Plant (Graphics)",
            "dates": "Jan 2009- April 2009",
            "description": "Designed a model in C++",
            "images": ["https://www.youtube.com/watch?v=wh53wePkFw8"]
        }
    ],
    display: function() {
        //   projects.display = function() {
        if (projects.projects.length > 0) {
            //for (i in projects.projects) {
            projects.projects.forEach(function(project) {
                $("#projects").append(HTMLprojectStart);
                var formattedTitle = HTMLprojectTitle.replace("%data%", project.title);
                $(".project-entry:last").append(formattedTitle);
                var formattedDates = HTMLprojectDates.replace("%data%", project.dates);
                $(".project-entry:last").append(formattedDates);
                var formattedDescription = HTMLprojectDescription.replace("%data%", project.description);
                $(".project-entry:last").append(formattedDescription);
                var formattedImages = HTMLprojectImage.replace("%data%", project.images);
                $(".project-entry:last").append(formattedImages);
            });
        }


    }
};
projects.display();

//map
/*
function initMap() {
        var myLatLng = {lat: -25.363, lng: 131.044};

        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 4,
          center: myLatLng
        });

        var marker = new google.maps.Marker({
          position: myLatLng,
          map: map,
          title: 'Hello World!'
        });
      }

//      $("#mapDiv").append(initMap);
//*/
$("#mapDiv").append(googleMap);