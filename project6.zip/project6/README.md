## Udacity Front-end Nonodegree - Project 6
>>>> Website Optimization

A) Instructions-to open the file
      1)unzip project6.zip file with the use of winzip software
      2)after unziping,click on index.html
                 index.html is the main file which is linked to the all the files.


B) Optimizations
     
   a)Optimizations in index.html 
       1)move the css part in the html file which will help in improving the webpage
       2)Added media="print" to the print.css part
       3)created a seperate file called googleanalyticsjs and added async to it,ths will help to improve the performance .By the time the whole webpage will be loaded and till that time this googleanalytics.js will get loaded
       4)added async to perfmatters.js


   b)Optimizations in main.js
       1)revamped the code to calculate the number of pizzas needed , based on browser inner dimensions.
       2)moved the document.body request out of for loop in the changePizzaSizes and updatePositions functions which prevents the browser from having to render the page every time the loop iterates
       3)stored the needed DOM elements so that the brower isn't querying the DOM every time the for loops are iterated in the updatePositions and changePizzaSizes funcitons
       4)in changePizzaSizes function ,created an additional for loop for setting the element's width. 
